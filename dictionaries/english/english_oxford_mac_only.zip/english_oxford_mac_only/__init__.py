__version__ = 1

import os
from .macdict import lookup_word
path = os.path.abspath(os.path.dirname(__file__))

querried = True
internet = False

def load_dictionary():
    pass
    
def querry_word(word):
    defn = lookup_word(word)
    if defn:
        return [defn]
    else:
        return ''

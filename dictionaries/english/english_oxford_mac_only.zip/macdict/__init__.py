from .dictionary import lookup_word


__version__ = '0.1.4'
__all__ = ['lookup_word']

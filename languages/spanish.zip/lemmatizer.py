#get possible lemmas using naive stemming
import re

def lemmatize(word): #get lemmas [SET] from a word
    word=word.lower()
    lemmas = [word,]
    
    suffix1 = word[-1:]
    suffix2 = word[-2:]
    
    if suffix1 == 'a':
        lemmas.append(word[:-1]+'o')
    if suffix2 == 'as':
        lemmas.append(word[:-2]+'o')
        
    if suffix1 == 's':
        lemmas.append(word[:-1])
    if suffix2 == 'es':
        lemmas.append(word[:-2])
    
    
    return set(lemmas) #return lemmas (no duplicates) #sort by length because loop breaks on finding first known 

#

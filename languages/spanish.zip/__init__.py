
import os
import pickle
import re

from . import lemmatizer

path = os.path.abspath(os.path.dirname(__file__))
package_name = os.path.basename(os.path.normpath(path))

def get_dict_version(dict):
    with open(os.path.join(path,'dictionaries',dict,'version.txt'),'r') as f:
        return int(f.read())
downloaded_dictionaries = os.listdir(os.path.join(path,'dictionaries')) #Check folder for all downloaded languages
dict_versions = {dict:get_dict_version(dict) for dict in downloaded_dictionaries}

def base_vocab(level): #-> set of basic vocabulary words
    file = open(os.path.join(path,'freq_list.txt'),'r',encoding='utf-8') #800 lines by cB recommended base = 670 corresponds to a frequency of 10^-6.7
    freqlist = []
    for line in file.readlines():
        freqlist.append(line.split())
    file.close()
    return set([word for line in freqlist[:level] for word in line])

def lemmatize(word): #-> lemmatizer function
    return lemmatizer.lemmatize(word)

#Variant Dict
    
def tokenize(sentence):
    return re.split('[0-9%*,.!?;&—():/“”’\-\'\"\s]+',sentence)
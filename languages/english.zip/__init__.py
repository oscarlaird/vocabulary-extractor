#English Language Modules

import os
import pickle
import re
import importlib

from . import lemmatizer
path = os.path.abspath(os.path.dirname(__file__))
package_name = os.path.basename(os.path.normpath(path))


abbreviations = '(?<! [a-zA-HJ-Z])(?<!\.[a-zA-HJ-Z])(?<! Mr| pg| st| St| rd| Mr| Ms| Dr| vs)(?<! esp| Mrs)'
level_samples = [["Imbecile, Bailiff, Postmortem"],
["Plebeian, Linearity, Wildebeest"],
["Muon, Scrivener, Symbolist"],
["Regnum, Blunderbuss, Polytechnics"],
["Transhumanism, Situs, Monetarist"],
["Ecotone, Foreshortening, Elephantiasis"]]

def base_vocab(level): #-> set of basic vocabulary words
    file = open(os.path.join(path,'freq_list.txt'),'r',encoding='utf-8') #800 lines by cB recommended base = 670 corresponds to a frequency of 10^-6.7
    freqlist = []
    for line in file.readlines():
        freqlist.append(line.split())
    file.close()
    return set([word for line in freqlist[:level] for word in line])

def lemmatize(word): #-> lemmatizer function
    return lemmatizer.lemmatize(word)

def variant_dict(): #-> dictionary of variant spellings
    file = open(os.path.join(path,'variants.pickle'),'rb')
    variant_dict = pickle.load(file) #Variant Dict
    file.close()
    return variant_dict
    
def tokenize(sentence):
    return re.split('[0-9%*,.!?;&—():/“”’\-\'\"\s]+',sentence)